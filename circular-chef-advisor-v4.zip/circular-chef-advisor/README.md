# Circular Chef Advisor

Prototipo local que propone tres recetas de reaprovechamiento a partir de los
alimentos disponibles. La interfaz se conecta exclusivamente con Ollama en el
propio equipo.

## Requisitos

- Node.js 22 o posterior.
- Ollama instalado y en ejecución.
- Un modelo local compatible. El prototipo utiliza `llama3.2:3b` por defecto.

## Puesta en marcha

1. Descarga el modelo la primera vez:

   ```bash
   ollama pull llama3.2:3b
   ```

2. Comprueba que Ollama está iniciado:

   ```bash
   ollama serve
   ```

3. La primera vez, instala las dependencias desde esta carpeta:

   ```bash
   npm install
   ```

4. Inicia la interfaz:

   ```bash
   npm run dev
   ```

5. Abre `http://localhost:3000`.

La luz de estado de la cabecera indicará si Ollama está conectado. Si ya tienes
otros modelos descargados, aparecerán automáticamente en el selector.

## Configuración opcional

Ollama se busca en `http://127.0.0.1:11434`. Para utilizar otra dirección:

```bash
OLLAMA_BASE_URL=http://127.0.0.1:11434 npm run dev
```

## Qué hace

- Acepta los sobrantes escritos en lenguaje natural o importados desde un
  archivo CSV o Excel (`.xlsx`).
- Al importar un archivo, muestra una previsualización editable de cada
  ingrediente, cantidad y unidad antes de permitir generar las recetas.
- Tiene en cuenta comensales, tiempo, estilo culinario y restricciones.
- Pide exactamente tres recetas en español, con ingredientes cuantificados y
  pasos de elaboración numerados.
- Calcula preparación, cocción, duración total y tamaño de la ración.
- Cada paso incluye duración y temperatura o potencia cuando corresponde.
- Advierte sobre ingredientes que el modelo considera dudosos y recuerda que
  toda propuesta debe validarse según el sistema APPCC del establecimiento.
- No envía la información a servicios externos.

## Formato de los archivos

La primera hoja de un archivo Excel, o el CSV completo, debe contener estas
columnas recomendadas:

| ingrediente | cantidad | unidad |
| --- | ---: | --- |
| Tomate maduro | 2.5 | kg |
| Pan del desayuno | 3 | barras |
| Queso | 500 | g |

También se reconocen encabezados equivalentes como `producto`, `alimento`,
`peso`, `nombre`, `ingredient`, `amount` o `unit`. Los CSV pueden utilizar
coma, punto y coma o tabulador como separador. Si no hay encabezados, la
aplicación interpreta las tres primeras columnas en el orden ingrediente,
cantidad y unidad.

Después de seleccionar el archivo, revisa y corrige la tabla de
previsualización. No se generarán recetas mientras exista alguna fila sin
nombre, sin unidad o con una cantidad que no sea mayor que cero.

## Verificación

```bash
npm run build
npm test
```
